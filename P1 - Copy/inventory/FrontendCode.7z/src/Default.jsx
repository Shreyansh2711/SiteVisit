import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const Default = () => {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen bg-cover bg-center bg-no-repeat flex flex-col"
      style={{
        backgroundImage:
          "url('https://img.freepik.com/premium-vector/wireless-network-highspeed-mobile-internet-signal-network_123447-5061.jpg?w=826')"
      }}
    >
      {/* Overlay with reduced opacity for more visible background */}
      <div className="bg-white/60 min-h-screen w-full flex flex-col">

        {/* Navbar */}
        <header className="flex justify-between items-center px-6 py-4 shadow-md bg-white/70">
          <div className="flex items-center text-red-600 font-bold text-xl">
            <span>OUTWORKS SOLUTIONS</span>
          </div>
          <button
            onClick={() => navigate("/login")}
            className="bg-red-500 hover:bg-red-600 text-white font-medium py-2 px-4 rounded"
          >
            Login
          </button>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex flex-col justify-center items-center text-center px-4">
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-4xl md:text-6xl font-bold text-black mb-6"
          >
            Customer Churn Prediction Model
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 1 }}
            className="text-gray-700 text-lg max-w-2xl mb-8"
          >
            Predict customer behavior and reduce churn with our powerful AI-driven insights. 
            Stay ahead by identifying risks and acting early.
          </motion.p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-6 rounded shadow"
          >
            Request a Demo
          </motion.button>
        </main>

      </div>
    </div>
  );
};

export default Default;
