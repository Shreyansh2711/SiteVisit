import React, { useState } from "react";

const P1 = () => {
  const [customerData, setCustomerData] = useState({
    input1: "",
    input2: "",
    input3: "",
    input4: "",
    input5: "",
    input6: "",
    input7: "",
    input8: "",
    input9: "",
    input10: "",
    input11: "",
    input12: ""
  });
  const [prediction, setPrediction] = useState(null);

  const handleInputChange = (e) => {
    setCustomerData({ ...customerData, [e.target.name]: e.target.value });
  };

  const handlePredict = () => {
    setPrediction("Prediction: Likely to churn");
  };

  const dropdownOptions = ["Yes", "No", "Maybe"];

  return (
    <div
      className="min-h-screen w-full bg-cover bg-center bg-no-repeat relative p-8"
      style={{
        backgroundImage:
          "url('https://img.freepik.com/premium-vector/wireless-network-highspeed-mobile-internet-signal-network_123447-5061.jpg?w=826')"
      }}
    >
      {/* White overlay for readability */}
      <div className="absolute inset-0 bg-white/60 z-0" />

      <div className="relative z-10 flex items-center justify-center h-full">
        <div className="bg-white shadow-2xl rounded-xl w-full max-w-6xl p-10 flex flex-col gap-10">
          {/* Heading */}
          <div className="flex items-center">
            <h1 className="text-4xl font-bold text-blue-700 mr-6">
              Customer Churn Prediction
            </h1>
          </div>

          {/* Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Form Inputs */}
            <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i}>
                  <label className="block text-sm text-gray-600 mb-1">
                    Input {i + 1}
                  </label>
                  <select
                    name={`input${i + 1}`}
                    value={customerData[`input${i + 1}`]}
                    onChange={handleInputChange}
                    className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400"
                  >
                    <option value="">Select</option>
                    {dropdownOptions.map((option, idx) => (
                      <option key={idx} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                </div>
              ))}
            </div>

            {/* Prediction Panel */}
            <div className="bg-blue-50 rounded-xl shadow p-6 flex flex-col justify-between">
              <div>
                <h2 className="text-xl pl-12 font-semibold text-gray-800 mb-4">
                  Prediction Result
                </h2>
                <button
                  onClick={handlePredict}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-md text-lg transition-all mb-6 transform hover:scale-105"
                >
                  Predict
                </button>
                {prediction && (
                  <div className="bg-white text-blue-800 p-4 rounded shadow text-center font-medium">
                    {prediction}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default P1;
