import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const Afterlogin = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/"); // Navigates to Default component
  };

  return (
    <div
      className="h-screen w-screen bg-cover bg-center bg-no-repeat relative overflow-hidden"
      style={{
        backgroundImage:
          "url('https://img.freepik.com/premium-vector/wireless-network-highspeed-mobile-internet-signal-network_123447-5061.jpg?w=826')"
      }}
    >
      {/* White overlay to improve readability */}
      <div className="absolute inset-0 bg-white/60 z-0" />

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full bg-gradient-to-br from-white to-blue-100 shadow-lg z-50 transition-all duration-300 ease-in-out ${
          menuOpen ? "w-52" : "w-14"
        }`}
      >
        <div className="flex flex-col h-full justify-between">
          {/* Toggle button */}
          <div>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="text-xl p-4 focus:outline-none hover:bg-white/30 transition rounded"
              title="Toggle Menu"
            >
              ☰
            </button>

            {/* Greeting */}
            {menuOpen && (
              <div className="px-4 mt-2">
                <h2 className="text-lg font-semibold text-blue-700 mb-1">
                  Welcome, User!
                </h2>
                <p className="text-sm text-gray-600">
                  Navigate your apps and tools.
                </p>
              </div>
            )}
          </div>

          {/* Logout */}
          {menuOpen && (
            <div className="p-4">
              <button
                onClick={handleLogout}
                className="w-full bg-red-500 hover:bg-red-600 text-xs p-2 rounded text-white transition"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Wrapper */}
      <div
        className={`relative z-10 transition-all duration-300 ease-in-out ${
          menuOpen ? "pl-52" : "pl-14"
        } h-full flex flex-col`}
      >
        {/* Navbar */}
        <nav className="flex justify-between items-center pl-4 pr-10 py-4 bg-white/80 shadow-md w-full">
          <div className="text-3xl font-extrabold text-blue-700">OUTWORKS</div>
          <div className="flex gap-4">
            <Link to="/home">
              <button className="px-4 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-all">
                App1
              </button>
            </Link>
            <Link to="#">
              <button className="px-4 py-2 bg-gray-200 text-blue-600 rounded-full hover:bg-gray-300 transition-all">
                App2
              </button>
            </Link>
            <Link to="#">
              <button className="px-4 py-2 bg-gray-200 text-blue-600 rounded-full hover:bg-gray-300 transition-all">
                App3
              </button>
            </Link>
          </div>
        </nav>

        {/* Centered Content */}
        <div className="flex flex-1 items-center justify-center px-6">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-center max-w-2xl"
          >
            <h1 className="text-5xl font-extrabold text-blue-700 mb-6">
              Welcome to ChurnX
            </h1>
            <p className="text-lg text-gray-700 mb-4">
              Predict customer churn with precision using our AI-powered platform.
              Gain insights and take action before it’s too late.
            </p>
            <p className="text-md text-gray-600 mb-8">
              Join data-driven businesses in improving customer retention, enhancing loyalty, and boosting long-term revenue with ease.
            </p>
            <Link to="/homepage">
              <button className="px-8 py-3 bg-blue-600 text-white text-lg rounded-full shadow hover:bg-blue-700 transition-all">
                Get Started
              </button>
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Afterlogin;
