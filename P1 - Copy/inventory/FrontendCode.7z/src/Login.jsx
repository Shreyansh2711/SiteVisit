import React, { useState } from "react";
import { useNavigate } from "react-router-dom";




const Login = () => {
    const navigate = useNavigate();

  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
    email: "",
    phone: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleLogin = () => {
    if (
      formData.username === "testuser" &&
      formData.password === "testpass"
    ) {
      alert("Logged in successfully as Test User!");
      navigate("/home");
    } else {
      alert("Invalid credentials");
    }
  };
  
  const handleTestLogin = () => {
    // alert("Logged in as Guest Test User!");
    navigate("/home");
  };

  const handleRegister = () => {
    alert(`Registered with\nUsername: ${formData.username}\nEmail: ${formData.email}\nPhone: ${formData.phone}`);
  };

  return (
    <div
      className="flex justify-center items-center min-h-screen bg-cover bg-center"
      style={{
        backgroundImage:
          'url("https://th.bing.com/th/id/R.d0ff94ddf008cdfb9f0739ed1fc7b114?rik=ElfXE7FFby0imQ&riu=http%3a%2f%2fwww.hillenvantol.nl%2fwp-content%2fuploads%2fwereld-met-connecties.jpg&ehk=KJSmZGm0yKKt%2fEelVLFb87EFFQKY%2bjz4jItcr3vV%2bBA%3d&risl=&pid=ImgRaw&r=0")'
      }}
    >
      <div className="w-full max-w-md shadow-xl rounded-2xl p-6 bg-white bg-opacity-90">
        <div>
          <h2 className="text-2xl font-bold mb-4 text-center">
            {isLogin ? "Login" : "Register"}
          </h2>

          <input
            name="username"
            placeholder="Username"
            value={formData.username}
            onChange={handleChange}
            className="w-full p-2 border border-gray-300 rounded mb-3"
          />

          <input
            name="password"
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            className="w-full p-2 border border-gray-300 rounded mb-3"
          />

          {!isLogin && (
            <>
              <input
                name="email"
                type="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded mb-3"
              />
              <input
                name="phone"
                type="tel"
                placeholder="Phone Number"
                value={formData.phone}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded mb-3"
              />
            </>
          )}

          <button
            className="w-full p-2 bg-blue-500 text-white rounded mb-2"
            onClick={isLogin ? handleLogin : handleRegister}
          >
            {isLogin ? "Login" : "Register"}
          </button>

          <button
            className="w-full p-2 border border-blue-500 text-blue-500 rounded mb-2"
            onClick={handleTestLogin}
          >
            Login as Test User
          </button>

          <p className="text-center text-sm mt-4">
            {isLogin ? "Don't have an account?" : "Already have an account?"} {" "}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-blue-500 underline"
            >
              {isLogin ? "Register" : "Login"}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;