
import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from './Login'; 
import Default from './Default';
import Afterlogin from './Afterlogin';
import P1 from './P1';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Default />} />          {/* Default Landing Page */}
        <Route path="/login" element={<Login />} />       {/* Login Route */}
        <Route path="/home" element={<Afterlogin />} />
        <Route path="/homepage" element={<P1 />} /> {/* Renamed route to avoid conflict */}
      </Routes>
    </Router>
  );
}

export default App;
